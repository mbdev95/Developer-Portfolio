// ----- Players Class
class Player {
  constructor(name, id, active) {
    this.name = name;
    this.id = id;
    this.active = active;
    this.weapon = {weapon: []};
    // this.score = this.getScore(); 
  } 

  // get getScore() {
  
  // }
}

