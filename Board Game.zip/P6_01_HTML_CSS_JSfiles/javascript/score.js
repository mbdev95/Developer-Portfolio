// ----- Score Class
// class Score {
//   constructor(player) {
//     this.player = this.player;
//     this.pointsRemaining = this.pointsRemaining();
//     this.damage = this.weaponDamage();
//   }
// Score - pointsRemaing() - method determining the number of points remaining a player has before he loses the game.
//   get pointsRemaining() {

//   }

// Score - weaponDamage() - method storing each weapons value that a player has.
//   get weaponDamage() {

//   }
// }